<?php
/**
 * Template Name: Honour Roll Page
 */
get_header();
?>

<div class="bottomMenu">      
    <?php $image = get_field('advertisement_left'); ?>
    <img class="img-responsive img-thumbnail"  src="<?php echo $image['url']; ?>" alt="" />          
</div>
<div class="bottomMenu bottomMenu-1">
    <?php $image = get_field('advertisement_right'); ?>
    <img class="img-responsive mr-bott10 pull-right"  src="<?php echo $image['url']; ?>" alt="" />  

    <?php $image = get_field('advertisement_right_second'); ?>
    <img class="img-responsive pull-right"  src="<?php echo $image['url']; ?>" alt="" />  
</div>

<div class="container">

    <ol class="breadcrumb mr-top20">
        <li><?php if (function_exists('qt_custom_breadcrumbs')) qt_custom_breadcrumbs(); ?></li>
    </ol>

    <div class="botgrapper_wrp mr-top30">  

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3><?php the_title();?></h3>
                <div class="progress">
                    <div style="width: 20%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="20" role="progressbar" class="progress-bar progress-bar-info"><span class="sr-only">20% Complete</span></div>
                </div>

                <div class="africa-map">
                    <div class="row">
                        <?php
                        if (have_rows('honoured_persons')):
                            // loop through rows (parent repeater)
                            while (have_rows('honoured_persons')): the_row();
                                ?>
                                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                    <div class="hall-fame">
                                        <?php   $image = get_sub_field('image');?>
                                        <img class="img-responsive center-block hall-img" src="<?php echo $image['url']; ?>" alt="1">
                                        <div class="hall-frame"></div>
                                        <h4><?php the_sub_field('name'); ?></h4>
                                        <p><?php the_sub_field('description'); ?></p>
                                        <p><b>READ MORE</b></p>
                                    </div>
                                </div>
                                <?php
                            endwhile;
                        endif;
                        ?>        
                    </div>
                </div>
                <hr>

            </div>
        </div>    
    </div>
</div>
<?php get_footer(); ?>