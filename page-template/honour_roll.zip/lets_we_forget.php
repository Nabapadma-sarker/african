<?php
/**
 * Template Name: Lest We Forget Page
 */
get_header();
?>
<div class="bottomMenu">      
    <?php $image = get_field('advertisement_left',805); ?>
    <img class="img-responsive img-thumbnail"  src="<?php echo $image['url']; ?>" alt="" />          
</div>
<div class="bottomMenu bottomMenu-1">
    <?php $image = get_field('advertisement_right',805); ?>
    <img class="img-responsive mr-bott10 pull-right"  src="<?php echo $image['url']; ?>" alt="" />  

    <?php $image = get_field('advertisement_right_second',805); ?>
    <img class="img-responsive pull-right"  src="<?php echo $image['url']; ?>" alt="" />  
</div>

<div class="container">

    <ol class="breadcrumb mr-top20">
  <li><?php if (function_exists('qt_custom_breadcrumbs')) qt_custom_breadcrumbs(); ?></li>
    </ol>

    <div class="botgrapper_wrp mr-top30">  

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3>Lest we Forget</h3>
                <div class="progress">
                    <div style="width: 20%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="20" role="progressbar" class="progress-bar progress-bar-info"><span class="sr-only">20% Complete</span></div>
                </div>

                <div class="">
                    <div class="row">
                        <?php
                        $args = array(
                            'post_type' => 'lestforget',
                            'order' => 'asc'
                        );
                        query_posts($args);
                        // The Loop
                        while (have_posts()) : the_post();
                            ?>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">                  
                                <h4><b><?php the_field(lest_we_forget);?></b></h4>
                                <p class="lest-brd"><?php the_title(); ?></p>
                                <?php $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), ''); ?>
                                    <img class="img-responsive mr-bott20" src="<?php echo $large_image_url[0] ?>" alt="<?php the_title();?>">  
                                
                                <?php echo substr(get_the_content(), 0, 100); ?><br>
                                <a href="<?php the_permalink();?>">READ MORE >></a>
                                <hr class="mr-top40">
                            </div>
                            <?php
                        endwhile;
                        // Reset Query
                        wp_reset_query();
                        ?>
                    </div>
                </div>
            </div>
        </div>    
    </div>
</div>
<?php get_footer(); ?>